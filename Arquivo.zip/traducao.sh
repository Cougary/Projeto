#!/bin/bash

read -p "Digite a palavra que deseja traduzir: "
trans $REPLY


